# Bingo Friends

A simple Android Bingo game for 2–10 friends.

## Features
- 2 to 10 players
- Player names
- Random 5×5 cards using numbers 1–25
- Shared number caller
- Called-number history
- Tap called numbers to mark/unmark
- Row, column and diagonal Bingo checking
- New Game

## Build
1. Install Android Studio.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on your Android phone.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and compile SDK 35.
