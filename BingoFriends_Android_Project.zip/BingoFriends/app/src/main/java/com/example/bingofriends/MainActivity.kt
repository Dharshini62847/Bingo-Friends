package com.example.bingofriends

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private var playerCount = 2
    private val names = mutableListOf<String>()
    private val cards = mutableListOf<List<Int>>()
    private val marked = mutableListOf<MutableSet<Int>>()
    private val called = mutableListOf<Int>()
    private var currentPlayer = 0
    private lateinit var lastNumber: TextView
    private lateinit var cardGrid: GridLayout
    private lateinit var playerSpinner: Spinner
    private lateinit var calledText: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSetup()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float = 16f): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(Color.rgb(35,35,35))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

    private fun button(label: String): MaterialButton =
        MaterialButton(this).apply {
            text = label
            isAllCaps = false
            minHeight = dp(48)
        }

    private fun showSetup() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.WHITE)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("🎱 Bingo Friends", 28f))
        root.addView(text("Choose how many friends are playing.", 16f))

        val countSpinner = Spinner(this)
        countSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            (2..10).map { "$it players" })
        root.addView(countSpinner)

        val namesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(namesBox)

        fun refreshNames() {
            playerCount = countSpinner.selectedItemPosition + 2
            namesBox.removeAllViews()
            repeat(playerCount) { i ->
                val input = EditText(this).apply {
                    hint = "Player ${i+1} name"
                    setSingleLine()
                    textSize = 16f
                    setPadding(dp(10), dp(4), dp(10), dp(4))
                }
                input.tag = i
                namesBox.addView(input, LinearLayout.LayoutParams(-1, dp(58)))
            }
        }
        countSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { refreshNames() }
        }
        refreshNames()

        val start = button("Start Game")
        start.setOnClickListener {
            names.clear()
            for (i in 0 until playerCount) {
                val e = namesBox.getChildAt(i) as EditText
                names.add(e.text.toString().trim().ifEmpty { "Player ${i+1}" })
            }
            startGame()
        }
        root.addView(start, LinearLayout.LayoutParams(-1, dp(56)))
    }

    private fun startGame() {
        cards.clear(); marked.clear(); called.clear(); currentPlayer = 0
        repeat(playerCount) {
            cards.add((1..25).shuffled())
            marked.add(mutableSetOf())
        }
        showGame()
    }

    private fun showGame() {
        root.removeAllViews()
        root.addView(text("🎱 Bingo Friends", 28f))
        status = text("0 of 25 numbers called", 15f)
        root.addView(status)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        lastNumber = text("—", 32f)
        top.addView(lastNumber, LinearLayout.LayoutParams(0, dp(70), 1f))
        val call = button("Call Number")
        call.setOnClickListener { callNumber() }
        top.addView(call)
        root.addView(top)

        root.addView(text("Called:"))
        calledText = text("None yet", 14f)
        root.addView(calledText)

        playerSpinner = Spinner(this)
        playerSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        playerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                currentPlayer = pos
                renderCard()
            }
        }
        root.addView(playerSpinner)

        cardGrid = GridLayout(this).apply {
            columnCount = 5
            rowCount = 6
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        root.addView(cardGrid)

        val bingo = button("🎉 BINGO!")
        bingo.setOnClickListener { checkBingo() }
        root.addView(bingo)

        val newGame = button("New Game")
        newGame.setOnClickListener { showSetup() }
        root.addView(newGame)

        renderCard()
    }

    private fun renderCard() {
        cardGrid.removeAllViews()
        listOf("B","I","N","G","O").forEach {
            val h = text(it, 13f).apply { gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) }
            cardGrid.addView(h, GridLayout.LayoutParams().apply {
                width = 0; height = dp(35); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            })
        }
        cards[currentPlayer].forEachIndexed { index, n ->
            val b = button(n.toString())
            b.textSize = 18f
            b.setPadding(0,0,0,0)
            b.setBackgroundColor(if (marked[currentPlayer].contains(n)) Color.rgb(103,80,164) else Color.WHITE)
            b.setTextColor(if (marked[currentPlayer].contains(n)) Color.WHITE else Color.DKGRAY)
            b.setOnClickListener {
                if (called.contains(n)) {
                    if (!marked[currentPlayer].add(n)) marked[currentPlayer].remove(n)
                    renderCard()
                } else {
                    Toast.makeText(this, "That number has not been called yet.", Toast.LENGTH_SHORT).show()
                }
            }
            cardGrid.addView(b, GridLayout.LayoutParams().apply {
                width = 0; height = dp(65)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
    }

    private fun callNumber() {
        if (called.size == 25) return
        val remaining = (1..25).filter { !called.contains(it) }
        val n = remaining.random()
        called.add(n)
        lastNumber.text = n.toString()
        calledText.text = called.joinToString("  ")
        status.text = "${called.size} of 25 numbers called"
        renderCard()
    }

    private fun checkBingo() {
        val c = cards[currentPlayer]
        val m = marked[currentPlayer]
        var win = false
        for (r in 0..4) if ((0..4).all { m.contains(c[r*5+it]) }) win = true
        for (col in 0..4) if ((0..4).all { m.contains(c[it*5+col]) }) win = true
        if ((0..4).all { m.contains(c[it*5+it]) }) win = true
        if ((0..4).all { m.contains(c[it*5+(4-it)]) }) win = true
        Toast.makeText(this,
            if (win) "🎉 ${names[currentPlayer]} has BINGO!" else "Not Bingo yet!",
            Toast.LENGTH_LONG).show()
    }
}
